package com.dev.robertpertuz.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductBackenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductBackenApplication.class, args);
	}

}
